﻿Dear Editor of *Sustainability*,
 
I am writing to submit our manuscript entitled, "**Navigating the Polycrisis: Institutional Responses and Cluster Resilience in China's Traditional Textile Industry**," for consideration as an Original Research Article in your esteemed journal, specifically within the section related to Economic and Business Aspects of Sustainability.
 
In the current era of "polycrisis"—characterized by fading globalization dividends, stringent environmental regulations, and disruptive technological shifts—traditional labor-intensive industrial clusters in developing economies are facing unprecedented existential threats. While the literature on Regional Economic Resilience (RER) has grown significantly, it often treats local institutional mechanisms as a "black box" and relies heavily on macro-level econometric correlations.
 
Our study addresses this critical gap by conducting a 25-year (2000–2024) longitudinal mixed-methods single-case study on the Gaoyang towel cluster in China. We propose a novel "**Policy-Industry Co-evolution**" framework, uncovering the micro-transmission mechanisms of *compliance cost socialization* (through heavy environmental infrastructure) and *transaction cost reduction* (through digital and branding empowerment). 
 
**Key Innovations and Contributions of this paper include:**
1. **Methodological Advancement (Mixed-Methods):** We overcome the "representativeness" dilemma of traditional single-case studies by integrating Computational Social Science with causal inference. We utilize **Dynamic BERTopic** to objectively quantify the dynamic shifts in local government policy foci over 25 years. To ensure construct validity and mitigate LLM hallucination risks, we employed a rigorous Placebo Topic Test and followed the latest validation frameworks for LLM annotations.
2. **Robust Causal Triangulation:** We triangulate our NLP findings using the **Synthetic Control Method (SCM)** and **Interrupted Time Series (ITS)** on a panel dataset. We provide robust evidence that agile policy shifts toward environmental infrastructure successfully forged the cluster's "baseline resilience."
3. **Deep Heterogeneity and Mechanism Analysis:** Moving beyond average treatment effects, we introduce real-world industry price indices and analyze dynamic heterogeneity across value chain segments (manufacturing vs. distribution) and firm sizes, demonstrating how policy mixes catalyzed the leap to "value resilience."
 
We believe our paper aligns perfectly with the aims and scope of *Sustainability*, as it provides a highly rigorous, interdisciplinary perspective on regional resilience, industrial policy, and institutional entrepreneurship. Furthermore, to align with the journal's open science policies, all data and code supporting this study will be made openly available.
 
This manuscript is original, has not been published previously, and is not under consideration for publication elsewhere. All authors have approved the manuscript and agree with its submission to your journal. The authors declare no conflict of interest.
 
Thank you for your time and consideration. We look forward to your positive response.
 
Sincerely,
 
Yiwen Sun
School of Mathematics and Statistics
Beijing Technology and Business University
Email: yver_sun@163.com
 
Yanlin Shi (Corresponding Author)
School of Languages and Communication
Beijing Technology and Business University
Email: yls@btbu.edu.cn
